MYANMAR LAW LIBRARY — စတင်ဗားရှင်း 0.1

ပါဝင်ပြီးသော အခြေခံလုပ်ဆောင်ချက်များ
- Modern dark-blue / gold interface
- မြန်မာဘာသာ UI အခြေခံ
- PDF ဖိုင်များကို ဖုန်းမှ ထည့်သွင်းခြင်း
- စာအုပ်ရှာဖွေခြင်း၊ သိမ်းထားခြင်း
- ထည့်ထားသော PDF ကို ဖွင့်ဖတ်ခြင်း
- Local browser storage ဖြင့် အခြေခံ offline အသုံးပြုမှု

သတိပြုရန်
- ဤ project သည် စတင်ဗားရှင်း / prototype ဖြစ်ပြီး ဥပဒေ PDF များကို ကြိုတင်ထည့်မထားပါ။
- ဥပဒေစာသားများကို တရားဝင်ထုတ်ပြန်ချက်၊ ပြင်ဆင်ချက်နှင့် လက်ရှိအသက်ဝင်မှုတို့ဖြင့် စစ်ဆေးပြီးမှ ထည့်သွင်းပါ။
- ဤ app သည် ဥပဒေအကြံဉာဏ် မဟုတ်ပါ။

APK ထုတ်ရန်
1. Android Studio တွင် ဤ project folder ကိုဖွင့်ပါ။
2. Gradle sync ပြီးပါက Build > Build Bundle(s) / APK(s) > Build APK(s) ကိုရွေးပါ။
3. APK ကို app/build/outputs/apk/debug/app-debug.apk တွင်ရနိုင်ပါမည်။

မှတ်ချက် - ဤပတ်ဝန်းကျင်တွင် Android SDK/Gradle build မရှိသဖြင့် APK binary ကို တိုက်ရိုက် compile မလုပ်ထားပါ။ Source project ကို Android Studio ဖြင့် build လုပ်နိုင်ရန် စီစဉ်ထားပါသည်။

ဥပဒေစာအုပ် Catalog (စတင်စာရင်း)
- app/src/main/assets/law_catalog.csv
- app/src/main/assets/law_catalog.json
ဤစာရင်းသည် စတင် catalog ဖြစ်ပြီး ဥပဒေအားလုံး၏ PDF များ ပါဝင်ပြီးပြီဟု မဆိုလိုပါ။
တရားဝင် PDF တိုက်ရိုက်ရရှိမှုကို သီးခြားဖော်ပြထားပြီး မအတည်ပြုနိုင်သော ဖိုင်ကို download ရနိုင်သည်ဟု မကြေညာပါ။
အထူးသဖြင့် SLRD ရှိ Land Law PDF ကို Farmland Law ဟု မရောထွေးရန် မှတ်ချက်ထည့်ထားသည်။
